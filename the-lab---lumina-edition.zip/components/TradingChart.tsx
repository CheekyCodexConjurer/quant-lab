import React, { useEffect, useRef, useState } from 'react';
import * as LightweightCharts from 'lightweight-charts';
import { Settings, RefreshCw, Layers, ChevronDown, Palette, Check, Monitor, TrendingUp, BarChart2, Eye, EyeOff } from 'lucide-react';

const generateData = (count = 2000) => {
  const data = [];
  let time = new Date('2023-01-01').getTime() / 1000;
  let value = 4000;
  for (let i = 0; i < count; i++) {
    time += 3600; // 1 hour
    const change = (Math.random() - 0.5) * 20;
    value += change;
    data.push({
      time: time as any,
      open: value - Math.random() * 5,
      high: value + Math.random() * 10,
      low: value - Math.random() * 10,
      close: value + Math.random() * 5,
    });
  }
  return data;
};

// Dropdown Menu Components
const Menu = ({ isOpen, onClose, children, className = "" }: any) => {
    if (!isOpen) return null;
    return (
        <div className={`absolute top-full mt-2 bg-white/90 backdrop-blur-xl border border-slate-100 shadow-xl rounded-2xl p-2 z-50 min-w-[200px] animate-in fade-in zoom-in-95 duration-200 ${className}`}>
             {children}
             {/* Backdrop for click-outside */}
             <div className="fixed inset-0 z-[-1]" onClick={onClose} />
        </div>
    );
};

export const TradingChart: React.FC = () => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<LightweightCharts.IChartApi | null>(null);
  const candleSeriesRef = useRef<LightweightCharts.ISeriesApi<"Candlestick"> | null>(null);
  const lineSeriesRef = useRef<LightweightCharts.ISeriesApi<"Line"> | null>(null);

  // State
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [data] = useState(generateData());
  
  const [config, setConfig] = useState({
      upColor: '#10b981',
      downColor: '#ef4444',
      bg: '#ffffff',
      grid: false,
  });

  const [indicators, setIndicators] = useState({
      ema: true,
      volume: false,
  });

  const [timeframe, setTimeframe] = useState('H1');

  const toggleMenu = (menu: string) => setActiveMenu(activeMenu === menu ? null : menu);

  // Initialize Chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = LightweightCharts.createChart(chartContainerRef.current, {
      layout: {
        background: { type: LightweightCharts.ColorType.Solid, color: config.bg },
        textColor: '#64748b',
      },
      grid: {
        vertLines: { visible: config.grid, color: 'rgba(226, 232, 240, 0.4)' },
        horzLines: { visible: config.grid, color: 'rgba(226, 232, 240, 0.4)' },
      },
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
      autoSize: true, // v5 support? We use ResizeObserver anyway for robustness
      rightPriceScale: {
        borderColor: 'transparent',
      },
      timeScale: {
        borderColor: 'transparent',
        timeVisible: true,
      },
      crosshair: {
        vertLine: {
            labelBackgroundColor: '#0ea5e9',
        },
        horzLine: {
            labelBackgroundColor: '#0ea5e9',
        }
      }
    });

    chartRef.current = chart;

    // Candle Series
    const candleSeries = chart.addSeries(LightweightCharts.CandlestickSeries, {
        upColor: config.upColor,
        downColor: config.downColor,
        borderVisible: false,
        wickUpColor: config.upColor,
        wickDownColor: config.downColor,
    });
    candleSeries.setData(data);
    candleSeriesRef.current = candleSeries;

    // EMA Series (Mock)
    const lineSeries = chart.addSeries(LightweightCharts.LineSeries, {
        color: '#0ea5e9',
        lineWidth: 2,
        crosshairMarkerVisible: false,
        visible: indicators.ema
    });
    const lineData = data.map(d => ({ time: d.time, value: (d.close + d.open) / 2 }));
    lineSeries.setData(lineData);
    lineSeriesRef.current = lineSeries;

    // Fit content
    chart.timeScale().fitContent();

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
        if (entries.length === 0 || entries[0].target !== chartContainerRef.current) return;
        const { width, height } = entries[0].contentRect;
        chart.applyOptions({ width, height });
    });

    resizeObserver.observe(chartContainerRef.current);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, []); // Re-run only on mount, updates handled separately

  // Update Config Effect
  useEffect(() => {
    if (chartRef.current) {
        chartRef.current.applyOptions({
            layout: { background: { type: LightweightCharts.ColorType.Solid, color: config.bg } },
            grid: {
                vertLines: { visible: config.grid },
                horzLines: { visible: config.grid },
            }
        });
    }
    if (candleSeriesRef.current) {
        candleSeriesRef.current.applyOptions({
            upColor: config.upColor,
            downColor: config.downColor,
            wickUpColor: config.upColor,
            wickDownColor: config.downColor,
        });
    }
  }, [config]);

  // Update Indicators Effect
  useEffect(() => {
    if (lineSeriesRef.current) {
        lineSeriesRef.current.applyOptions({ visible: indicators.ema });
    }
  }, [indicators]);

  return (
    <div className="h-full flex flex-col gap-4 animate-in fade-in duration-700">
      
      {/* Toolbar */}
      <div className="bg-white p-2 md:p-3 rounded-2xl shadow-soft flex flex-wrap justify-between items-center gap-4 relative z-20">
        
        {/* Left: Ticker & Timeframe */}
        <div className="flex items-center gap-2 md:gap-4">
           {/* Ticker Selector */}
           <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl">
             {['CL1!', 'ES1!', 'BTC1!'].map(ticker => (
               <button key={ticker} className={`px-3 py-2 rounded-lg text-xs md:text-sm font-bold transition-all ${ticker === 'CL1!' ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400 hover:text-slate-600'}`}>
                 {ticker}
               </button>
             ))}
           </div>
           
           <div className="h-6 w-px bg-slate-200 hidden md:block"></div>
           
           {/* Timeframe Selector */}
           <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl relative">
             {['M5', 'H1', 'D1'].map(tf => (
               <button 
                  key={tf} 
                  onClick={() => setTimeframe(tf)}
                  className={`w-9 h-8 rounded-lg text-xs font-bold transition-all ${timeframe === tf ? 'bg-slate-800 text-white shadow-md' : 'text-slate-400 hover:bg-slate-200'}`}
               >
                 {tf}
               </button>
             ))}
             
             {/* Extended Timeframes Dropdown */}
             <div className="relative">
                <button 
                    onClick={() => toggleMenu('timeframes')}
                    className={`w-9 h-8 rounded-lg flex items-center justify-center transition-all ${activeMenu === 'timeframes' || !['M5','H1','D1'].includes(timeframe) ? 'bg-sky-100 text-sky-600' : 'text-slate-400 hover:bg-slate-200'}`}
                >
                    <ChevronDown size={14} />
                </button>
                
                <Menu isOpen={activeMenu === 'timeframes'} onClose={() => setActiveMenu(null)}>
                    <div className="grid grid-cols-2 gap-1 p-1">
                        {['M1', 'M15', 'M30', 'H2', 'H4', 'W1', 'M1'].map(tf => (
                            <button 
                                key={tf}
                                onClick={() => { setTimeframe(tf); setActiveMenu(null); }}
                                className={`px-3 py-2 rounded-lg text-xs font-bold text-left hover:bg-slate-50 transition-colors ${timeframe === tf ? 'text-sky-600 bg-sky-50' : 'text-slate-500'}`}
                            >
                                {tf}
                            </button>
                        ))}
                    </div>
                </Menu>
             </div>
           </div>
        </div>

        {/* Right: Tools & Settings */}
        <div className="flex items-center gap-2 md:gap-3">
          
          {/* Indicators Menu */}
          <div className="relative">
              <button 
                onClick={() => toggleMenu('indicators')}
                className={`flex items-center gap-2 px-3 md:px-4 py-2 border rounded-xl text-sm font-medium transition-all shadow-sm
                    ${activeMenu === 'indicators' ? 'bg-sky-50 border-sky-200 text-sky-700' : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50'}`}
              >
                <Layers size={16} /> 
                <span className="hidden md:inline">Studies</span>
              </button>

              <Menu isOpen={activeMenu === 'indicators'} onClose={() => setActiveMenu(null)} className="right-0 w-64">
                <div className="p-3 pb-2 border-b border-slate-100 mb-2">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Studies</h4>
                </div>
                <div className="space-y-1">
                    <button 
                        onClick={() => setIndicators(prev => ({...prev, ema: !prev.ema}))}
                        className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 group"
                    >
                        <div className="flex items-center gap-3">
                            <TrendingUp size={16} className="text-sky-500" />
                            <span className="text-sm font-medium text-slate-700">EMA 20</span>
                        </div>
                        {indicators.ema ? <Eye size={16} className="text-slate-400" /> : <EyeOff size={16} className="text-slate-300" />}
                    </button>
                    <button 
                        onClick={() => setIndicators(prev => ({...prev, volume: !prev.volume}))}
                        className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 group"
                    >
                        <div className="flex items-center gap-3">
                            <BarChart2 size={16} className="text-purple-500" />
                            <span className="text-sm font-medium text-slate-700">Volume Profile</span>
                        </div>
                         {indicators.volume ? <Eye size={16} className="text-slate-400" /> : <EyeOff size={16} className="text-slate-300" />}
                    </button>
                </div>
              </Menu>
          </div>

          {/* Settings / Appearance Menu */}
          <div className="relative">
              <button 
                 onClick={() => toggleMenu('settings')}
                 className={`flex items-center gap-2 px-3 md:px-4 py-2 border rounded-xl text-sm font-medium transition-all shadow-sm
                    ${activeMenu === 'settings' ? 'bg-sky-50 border-sky-200 text-sky-700' : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50'}`}
              >
                <Palette size={16} /> 
                <span className="hidden md:inline">Style</span>
              </button>

              <Menu isOpen={activeMenu === 'settings'} onClose={() => setActiveMenu(null)} className="right-0 w-72">
                  <div className="space-y-4 p-2">
                      <div>
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 block">Candle Colors</label>
                          <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                  <span className="text-xs text-slate-500">Bullish</span>
                                  <div className="flex gap-2">
                                      {['#10b981', '#3b82f6', '#8b5cf6'].map(c => (
                                          <button 
                                            key={c} 
                                            onClick={() => setConfig(prev => ({...prev, upColor: c}))}
                                            className={`w-6 h-6 rounded-full border-2 transition-transform hover:scale-110 ${config.upColor === c ? 'border-slate-800 scale-110' : 'border-transparent'}`}
                                            style={{ backgroundColor: c }}
                                          />
                                      ))}
                                  </div>
                              </div>
                              <div className="space-y-2">
                                  <span className="text-xs text-slate-500">Bearish</span>
                                  <div className="flex gap-2">
                                      {['#ef4444', '#f97316', '#64748b'].map(c => (
                                          <button 
                                            key={c} 
                                            onClick={() => setConfig(prev => ({...prev, downColor: c}))}
                                            className={`w-6 h-6 rounded-full border-2 transition-transform hover:scale-110 ${config.downColor === c ? 'border-slate-800 scale-110' : 'border-transparent'}`}
                                            style={{ backgroundColor: c }}
                                          />
                                      ))}
                                  </div>
                              </div>
                          </div>
                      </div>

                      <div className="border-t border-slate-100 pt-4">
                           <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 block">Display</label>
                           <button 
                                onClick={() => setConfig(prev => ({...prev, grid: !prev.grid}))}
                                className="flex items-center justify-between w-full p-2 hover:bg-slate-50 rounded-lg text-sm text-slate-600"
                           >
                               <span>Show Grid Lines</span>
                               {config.grid && <Check size={14} className="text-emerald-500" />}
                           </button>
                      </div>
                  </div>
              </Menu>
          </div>

          <button className="w-10 h-10 flex items-center justify-center bg-lumina-accent text-white rounded-xl shadow-glow hover:bg-lumina-accentDark transition-colors">
            <RefreshCw size={18} />
          </button>
        </div>
      </div>

      {/* Chart Canvas Area - flex-1 ensures it takes all remaining space */}
      <div className="flex-1 bg-white rounded-[2rem] shadow-soft p-1 relative overflow-hidden z-10 border border-slate-50">
        <div ref={chartContainerRef} className="w-full h-full rounded-[1.8rem] overflow-hidden" />
        
        {/* Floating Legend */}
        <div className="absolute top-6 left-6 bg-white/80 backdrop-blur-md p-3 rounded-xl border border-slate-100 shadow-sm text-xs pointer-events-none z-20 animate-in fade-in slide-in-from-top-2 duration-700">
           <div className="flex items-center gap-2 mb-1.5">
             <div className="w-2 h-2 rounded-full" style={{ backgroundColor: config.upColor }}></div>
             <span className="font-bold text-slate-700">CL1! - Crude Oil Futures</span>
             <span className="text-slate-400">NYMEX</span>
           </div>
           {indicators.ema && (
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-sky-500"></div>
                <span className="font-bold text-slate-700">EMA 20</span>
                <span className="text-slate-400">4021.50</span>
            </div>
           )}
        </div>
      </div>
    </div>
  );
};
