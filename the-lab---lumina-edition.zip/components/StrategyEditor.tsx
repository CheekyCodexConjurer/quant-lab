import React, { useState } from 'react';
import { Play, Save, Download, Copy, Terminal, AlertCircle, File, Folder, Trash2, Edit2, Plus, ChevronDown, ChevronRight, FileCode } from 'lucide-react';

const mockCode = `from market_structure.core import calculate as _calculate

def calculate(inputs, settings=None):
    """
    Entry point used by The Lab.
    Delegates to market_structure.core but strips main series.
    """
    settings = settings or {}
    
    # Calculate Core Logic
    result = _calculate(inputs)
    
    if not isinstance(result, dict):
        return result

    series = result.get("series") or {}
    
    # Filter out main series for overlay
    if isinstance(series, dict):
        filtered_series = {k: v for k, v in series.items() if k != "main"}
    else:
        filtered_series = {}

    return {
        "series": filtered_series,
        "markers": result.get("markers") or [],
        "levels": result.get("levels") or []
    }
`;

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  parentId?: string;
  active?: boolean;
}

const initialFiles: FileNode[] = [
  // Root Folders
  { id: '1', name: 'strategies', type: 'folder' },
  { id: '2', name: 'indicators', type: 'folder' },
  { id: '3', name: 'market_structure', type: 'folder' },
  { id: '4', name: 'utils', type: 'folder' },

  // Strategy Files
  { id: '11', name: 'mean_reversion.py', type: 'file', parentId: '1' },
  { id: '12', name: 'trend_alpha.py', type: 'file', parentId: '1' },
  
  // Indicator Files & Subfolders
  { id: '21', name: 'custom', type: 'folder', parentId: '2' },
  { id: '211', name: 'rsi_divergence.py', type: 'file', parentId: '21' },
  { id: '22', name: 'vwap.py', type: 'file', parentId: '2' },

  // Market Structure Files
  { id: '31', name: 'core.py', type: 'file', parentId: '3' },
  { id: '32', name: 'pivots.py', type: 'file', parentId: '3' },

  // Utils Files
  { id: '41', name: 'helpers.py', type: 'file', parentId: '4' },
  
  // Root Files
  { id: '5', name: 'main.py', type: 'file', active: true },
  { id: '6', name: 'config.json', type: 'file' },
];

export const StrategyEditor: React.FC = () => {
  const [code, setCode] = useState(mockCode);
  const [files, setFiles] = useState<FileNode[]>(initialFiles);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['1', '2'])); // Default expanded folders
  const [consoleOutput, setConsoleOutput] = useState([
      { type: 'info', text: "> Loading 'market_structure' module..." },
      { type: 'success', text: "> Calculation completed in 42ms" },
      { type: 'info', text: "> Markers generated: 14" },
  ]);

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this item?')) {
        setFiles(files.filter(f => f.id !== id && f.parentId !== id)); // Remove item and children (simple check)
    }
  };

  const handleRename = (id: string, currentName: string, e: React.MouseEvent) => {
      e.stopPropagation();
      const newName = prompt("Rename item:", currentName);
      if (newName) {
          setFiles(files.map(f => f.id === id ? { ...f, name: newName } : f));
      }
  };

  const handleFileClick = (id: string) => {
      setFiles(files.map(f => ({ ...f, active: f.id === id })));
  };

  const toggleFolder = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      const newExpanded = new Set(expandedFolders);
      if (newExpanded.has(id)) {
          newExpanded.delete(id);
      } else {
          newExpanded.add(id);
      }
      setExpandedFolders(newExpanded);
  };

  const activeFile = files.find(f => f.active);

  const renderTree = (parentId?: string, depth = 0) => {
      const nodes = files.filter(f => f.parentId === parentId);
      
      // Sort: Folders first, then files
      nodes.sort((a, b) => {
          if (a.type === b.type) return a.name.localeCompare(b.name);
          return a.type === 'folder' ? -1 : 1;
      });

      if (nodes.length === 0) return null;

      return nodes.map(node => {
          const isExpanded = expandedFolders.has(node.id);
          const paddingLeft = depth * 12 + 12;

          return (
              <div key={node.id}>
                  <div 
                      onClick={(e) => node.type === 'folder' ? toggleFolder(node.id, e) : handleFileClick(node.id)}
                      className={`
                          group relative flex items-center gap-2 py-1.5 pr-2 rounded-lg cursor-pointer text-sm font-medium transition-all duration-200 select-none
                          ${node.active ? 'bg-sky-50 text-sky-700' : 'hover:bg-slate-50 text-slate-600'}
                      `}
                      style={{ paddingLeft: `${paddingLeft}px` }}
                  >
                      {/* Icon & Arrow */}
                      <span className="shrink-0 flex items-center gap-1.5 min-w-[24px]">
                           {node.type === 'folder' && (
                               <span className="text-slate-400">
                                  {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                               </span>
                           )}
                           {node.type === 'folder' ? (
                               <Folder size={14} className="text-yellow-400 fill-yellow-400/20" />
                           ) : (
                               <div className={node.active ? 'text-sky-500' : 'text-slate-400'}>
                                   {node.name.endsWith('.json') ? <FileCode size={14} /> : <File size={14} />}
                               </div>
                           )}
                      </span>

                      {/* Name */}
                      <span className="truncate">{node.name}</span>
                      
                      {/* Active Indicator */}
                      {node.active && <div className="w-1.5 h-1.5 rounded-full bg-sky-500 ml-auto mr-1 animate-in zoom-in"></div>}

                      {/* Hover Actions */}
                      <div className={`absolute right-1 flex items-center gap-1 ${node.active ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} transition-opacity bg-white/60 backdrop-blur-[2px] rounded-md pl-1`}>
                          <button 
                              onClick={(e) => handleRename(node.id, node.name, e)}
                              className="p-1 hover:bg-white rounded text-slate-400 hover:text-sky-500 transition-colors"
                              title="Rename"
                          >
                              <Edit2 size={10} />
                          </button>
                          <button 
                              onClick={(e) => handleDelete(node.id, e)}
                              className="p-1 hover:bg-white rounded text-slate-400 hover:text-red-500 transition-colors"
                              title="Delete"
                          >
                              <Trash2 size={10} />
                          </button>
                      </div>
                  </div>

                  {/* Recursively render children */}
                  {node.type === 'folder' && isExpanded && (
                      <div className="animate-in slide-in-from-top-1 fade-in duration-200 origin-top">
                          {renderTree(node.id, depth + 1)}
                      </div>
                  )}
              </div>
          );
      });
  };

  return (
    <div className="h-full flex gap-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      
      {/* File Tree / Sidebar */}
      <div className="w-64 bg-white rounded-[2rem] shadow-soft p-6 flex flex-col hidden lg:flex">
         <div className="flex items-center justify-between mb-6 px-2">
            <h3 className="font-bold text-slate-800">Workspace</h3>
            <button className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-sky-500 transition-colors">
                <Plus size={16} />
            </button>
         </div>
         
         <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 -ml-2">
            {renderTree()}
         </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex flex-col gap-6">
        {/* Toolbar */}
        <div className="bg-white p-4 rounded-2xl shadow-soft flex justify-between items-center">
           <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm font-medium text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                <span className="flex items-center gap-1"><Folder size={12} className="text-yellow-400 fill-yellow-400/20"/> {activeFile?.parentId ? files.find(f => f.id === activeFile.parentId)?.name : 'root'}</span>
                <span className="text-slate-300">/</span>
                <span className="text-slate-800 font-bold">{activeFile?.name || 'No file selected'}</span>
              </div>
              {activeFile && (
                  <span className="text-[10px] text-emerald-500 bg-emerald-50 px-2 py-1 rounded-md font-bold flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div> Edited
                  </span>
              )}
           </div>

           <div className="flex items-center gap-2">
              <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors" title="Copy">
                <Copy size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors" title="Download">
                <Download size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors" title="Save">
                <Save size={18} />
              </button>
              <button className="flex items-center gap-2 px-6 py-2 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl ml-2">
                <Play size={16} fill="white" /> Run
              </button>
           </div>
        </div>

        {/* Code Content */}
        <div className="flex-1 bg-white rounded-[2rem] shadow-soft p-0 overflow-hidden flex flex-col relative">
           <div className="flex-1 p-6 font-mono text-sm overflow-auto custom-scrollbar leading-relaxed">
             <textarea 
               value={code}
               onChange={(e) => setCode(e.target.value)}
               className="w-full h-full resize-none outline-none text-slate-700 selection:bg-sky-100"
               spellCheck={false}
             />
           </div>
           
           {/* Terminal / Console Overlay */}
           <div className="bg-slate-900 text-slate-300 p-4 font-mono text-xs border-t-4 border-slate-800">
              <div className="flex justify-between items-center mb-2 text-slate-500 uppercase tracking-widest text-[10px] font-bold">
                 <span className="flex items-center gap-2"><Terminal size={12} /> Console Output</span>
                 <button className="hover:text-white" onClick={() => setConsoleOutput([])}><AlertCircle size={12}/></button>
              </div>
              <div className="space-y-1 opacity-80 h-24 overflow-y-auto custom-scrollbar">
                {consoleOutput.map((log, i) => (
                    <p key={i} className={log.type === 'success' ? 'text-emerald-400' : 'text-slate-300'}>
                        {log.text}
                    </p>
                ))}
                <p className="animate-pulse">_</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};